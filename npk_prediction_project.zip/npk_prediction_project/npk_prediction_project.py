import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import joblib

# STEP 1: Load Dataset
train_df = pd.read_csv('data/train_NPK.csv')
test_df = pd.read_csv('data/test_NPK.csv')


# STEP 2: Clean NaN and Whitespaces
train_df.dropna(inplace=True)
test_df.dropna(inplace=True)

# ✅ Overwrite stage by week logic
def assign_stage(week):
    if week <= 10:
        return 'vegetative'
    elif week <= 20:
        return 'flowering'
    else:
        return 'fruiting'

train_df['stage'] = train_df['week'].apply(assign_stage)
test_df['stage'] = test_df['week'].apply(assign_stage)

# STEP 3: Sort
train_df = train_df.sort_values(by=['datetime', 'week']).reset_index(drop=True)
test_df = test_df.sort_values(by=['datetime', 'week']).reset_index(drop=True)

# STEP 4: Encode Stage
encoder = LabelEncoder()
train_df['stage'] = encoder.fit_transform(train_df['stage'])
test_df['stage'] = encoder.transform(test_df['stage'])

# STEP 5: Features & Targets
features = ['pH', 'EC', 'moisture', 'temperature', 'humidity', 'rainfall', 'stage', 'week']
targets = ['N', 'P', 'K']

X_train = train_df[features]
y_train = train_df[targets]
X_test = test_df[features]
y_test = test_df[targets]

# STEP 6: Normalize
scaler_X = MinMaxScaler()
scaler_y = MinMaxScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
y_train_scaled = scaler_y.fit_transform(y_train)
X_test_scaled = scaler_X.transform(X_test)
y_test_scaled = scaler_y.transform(y_test)

# STEP 7: Sequence
def create_sequences(X, y, seq_len):
    Xs, ys = [], []
    for i in range(len(X) - seq_len):
        Xs.append(X[i:i+seq_len])
        ys.append(y[i+seq_len])
    return np.array(Xs), np.array(ys)

seq_len = 10
X_seq, y_seq = create_sequences(X_train_scaled, y_train_scaled, seq_len)
X_test_seq, y_test_seq = create_sequences(X_test_scaled, y_test_scaled, seq_len)

# STEP 8: LSTM Model
model = Sequential([
    LSTM(128, return_sequences=True, input_shape=(X_seq.shape[1], X_seq.shape[2])),
    Dropout(0.3),
    LSTM(64),
    Dropout(0.3),
    Dense(32, activation='relu'),
    Dense(3)
])
model.compile(optimizer='adam', loss='mse')
model.summary()

# STEP 9: Train
history = model.fit(X_seq, y_seq, epochs=50, batch_size=16, validation_split=0.2, verbose=1)

# Save Model & Scalers
model.save('your_lstm_model.h5')
joblib.dump(scaler_X, 'scaler_X.pkl')
joblib.dump(scaler_y, 'scaler_y.pkl')

# STEP 10: Predict
y_pred_scaled = model.predict(X_test_seq)
y_pred = scaler_y.inverse_transform(y_pred_scaled)
y_true = scaler_y.inverse_transform(y_test_seq)

# Save Prediction Result
result = test_df.iloc[seq_len:].copy()
result[['Pred_N', 'Pred_P', 'Pred_K']] = y_pred
result[['True_N', 'True_P', 'True_K']] = y_true
result.to_csv('data/predicted_result_sorted.csv', index=False)
print("✅ Saved: data/predicted_result_sorted.csv")

# STEP 11: Accuracy
mae = mean_absolute_error(y_true, y_pred)
mse = mean_squared_error(y_true, y_pred)
r2 = r2_score(y_true, y_pred)
print(f"\n📊 Accuracy: MAE={mae:.2f}, MSE={mse:.2f}, R²={r2:.4f}")

# Detailed Accuracy
summary_df = pd.DataFrame({
    'Nutrient': ['N', 'P', 'K'],
    'MAE': [mean_absolute_error(y_true[:,0], y_pred[:,0]),
            mean_absolute_error(y_true[:,1], y_pred[:,1]),
            mean_absolute_error(y_true[:,2], y_pred[:,2])],
    'MSE': [mean_squared_error(y_true[:,0], y_pred[:,0]),
            mean_squared_error(y_true[:,1], y_pred[:,1]),
            mean_squared_error(y_true[:,2], y_pred[:,2])],
    'R²': [r2_score(y_true[:,0], y_pred[:,0]),
           r2_score(y_true[:,1], y_pred[:,1]),
           r2_score(y_true[:,2], y_pred[:,2])]
})
print("\n📊 Per Nutrient Metrics:\n")
print(summary_df.to_string(index=False))

# STEP 12: Graph
weekly_df = result.groupby('week').first().reset_index()

for nutrient in ['N', 'P', 'K']:
    plt.figure(figsize=(10, 4))
    plt.plot(weekly_df['week'], weekly_df[f'True_{nutrient}'], label=f'True {nutrient}', color='green')
    plt.plot(weekly_df['week'], weekly_df[f'Pred_{nutrient}'], label=f'Predicted {nutrient}', linestyle='--', color='blue')
    plt.title(f"{nutrient} Prediction vs Actual")
    plt.xlabel("Week")
    plt.ylabel(f"{nutrient} (mg/kg)")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

# STEP 13: Training Curve
plt.figure(figsize=(10, 5))
plt.plot(history.history['loss'], label='Training Loss', color='blue')
plt.plot(history.history['val_loss'], label='Validation Loss', color='orange')
plt.title("Training vs Validation Loss")
plt.xlabel("Epoch")
plt.ylabel("MSE Loss")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
