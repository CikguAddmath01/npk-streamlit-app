import streamlit as st
import numpy as np
import joblib
from tensorflow.keras.models import load_model
from PIL import Image

# 🌙 Dark Theme applied via .streamlit/config.toml (set manually)

# ✅ Load assets
model = load_model('your_lstm_model.h5', compile=False)
scaler_X = joblib.load('scaler_X.pkl')
scaler_y = joblib.load('scaler_y.pkl')
logo = Image.open('unimap.png')  # 📸 logo file

# ✅ Stage encoding
stage_dict = {'vegetative': 0, 'flowering': 1, 'fruiting': 2}

# ✅ Predict function
def predict_npk(pH, EC, moisture, temperature, humidity, rainfall, stage, week):
    try:
        stage_encoded = stage_dict[stage.lower()]
        input_features = np.array([[pH, EC, moisture, temperature, humidity, rainfall, stage_encoded, week]])
        input_scaled = scaler_X.transform(input_features)
        input_reshaped = np.reshape(input_scaled, (1, 1, input_scaled.shape[1]))
        pred_scaled = model.predict(input_reshaped)
        pred_npk = scaler_y.inverse_transform(pred_scaled)
        return pred_npk[0]
    except Exception as e:
        st.error(f"Prediction Error: {e}")
        return [0, 0, 0]

# ✅ Page setup
st.set_page_config(page_title="🌱 NPK Prediction Dashboard", layout="wide")
st.markdown("<style>h1, h2, h3 { color: #00FF88 !important; }</style>", unsafe_allow_html=True)

# ✅ Layout: 2 columns
col1, col2 = st.columns([2, 1])

with col2:
    st.image(logo, width=150)
    st.markdown("### UniMAP - Smart Farming AI")
    st.markdown("NPK Prediction using LSTM model trained on sensor & stage data.")
    st.markdown("---")

with col1:
    st.title("🌾 Smart NPK Predictor")

    with st.form("predict_form"):
        st.subheader("📥 Input Parameters")

        c1, c2 = st.columns(2)
        with c1:
            pH = st.number_input('Soil pH', 0.0, 14.0, value=6.5, step=0.1)
            EC = st.number_input('EC', 0.0, 10.0, value=1.0, step=0.1)
            moisture = st.number_input('Moisture (%)', 0.0, 100.0, value=30.0, step=1.0)
            humidity = st.number_input('Humidity (%)', 0.0, 100.0, value=60.0, step=1.0)
        with c2:
            temperature = st.number_input('Temperature (°C)', -10.0, 50.0, value=28.0, step=0.5)
            rainfall = st.number_input('Rainfall (mm)', 0.0, 1000.0, value=100.0, step=1.0)
            stage = st.selectbox('Growth Stage', ['vegetative', 'flowering', 'fruiting'])

        week = st.slider('Week of Growth', 1, 52, value=10)

        submitted = st.form_submit_button("🚀 Predict Now", use_container_width=True)

    if submitted:
        npk = predict_npk(pH, EC, moisture, temperature, humidity, rainfall, stage, week)
        st.markdown("---")
        st.subheader("📊 Predicted NPK Values")

        col_n, col_p, col_k = st.columns(3)
        col_n.metric("🌿 Nitrogen (N)", f"{npk[0]:.2f} mg/kg")
        col_p.metric("🌼 Phosphorus (P)", f"{npk[1]:.2f} mg/kg")
        col_k.metric("🍌 Potassium (K)", f"{npk[2]:.2f} mg/kg")
